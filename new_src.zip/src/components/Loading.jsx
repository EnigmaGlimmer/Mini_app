import React from 'react';

export default () => (
    <div className="d-flex justify-content-center align-items-center w-100 h-100">
        <div className="spinner-border text-primary" role="status" />
    </div>
);