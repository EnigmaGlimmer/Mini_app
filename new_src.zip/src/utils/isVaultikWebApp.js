export default function isVaultikWebApp(vaultikWindow) {
    return !vaultikWindow?.brandPubKey
}